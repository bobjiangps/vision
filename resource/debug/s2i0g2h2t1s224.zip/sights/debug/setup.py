from setuptools import setup, find_packages

# try:
#     from wheel.bdist_wheel import bdist_wheel as _bdist_wheel
#     class bdist_wheel(_bdist_wheel):
#         def finalize_options(self):
#             _bdist_wheel.finalize_options(self)
#             self.root_is_pure = False
# except ImportError:
#     bdist_wheel = None

def find_requires():
    requires = []
    with open("./requirements.txt", "r") as f:
        packages = f.read().strip().split("\n")
        for pkg in packages:
            requires.append(pkg)
    return requires

setup(
    name="sights",
    version="1.3.8.4",
    author="bjiang1",
    author_email="bo.jiang@activenetwork.com",
    description="auto test framework with AI",
    license="MIT",
    url="https://gitlab.dev.activenetwork.com/GlobalAutomation/framework3_dl/sights",
    # include_package_data=True,
    # package_data={
    #     "conf": ["config.yaml"]
    # },
    packages=find_packages(),
    package_data={"": ["*.yaml", "*.py", "*.c", "*.pyd", "*.so"]},
    # py_modules=["sights"],
    classifiers=[
            "License :: OSI Approved :: MIT License",
            "Programming Language :: Python :: 3",
            "Operating System :: OS Independent"
        ],
    python_requires=">=3.8",
    install_requires=find_requires(),
    dependency_links=[
        "https://artifacts.dev.activenetwork.com/artifactory/api/pypi/pypi_vitual/simple#egg=paddleocr-2.5.0.3.1"
    ]
    # cmdclass={'bdist_wheel': bdist_wheel}
)

# python setup.py sdist bdist_wheel


# from setuptools import setup
#
# setup(
#     name="sights",
#     version="1.0.0")