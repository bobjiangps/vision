# # 题目4
# numbers = input("请输入数字，以空格隔开\n")
# num_list = numbers.split(" ")
# num_dict = {}
# for i in num_list:
#     if i not in num_dict.keys():
#         num_dict[i] = 1
#     else:
#         num_dict[i] += 1
# print(f"结果是: {num_dict}")

# # 题目5
# numbers = input("请输入数字，以空格隔开\n")
# num_list = numbers.split(" ")
# num_list.sort(reverse=True)
# odd_count = 0
# for i in num_list:
#     if int(i) % 2 != 0:
#         odd_count += 1
# print(f"排列后的数字是: {num_list}")
# print(f"奇数个数为: {odd_count}")

# # 题目6
# number = input("请输入一个数字\n")
# print("-------")
# total = 0
# for seq in range(1, int(number)+1):
#     total += seq ** 2
# print(f"最后的累计结果是: {total}")

# # 题目8
# words = input("请输入你的文字，以-隔开\n")
# print(words.split("-"))

# # 题目7
# index = input("请输入一个数值以展示你期望的对应位置的字符\n")
# words = "hello python"
# index = int(index)
# if index < 0:
#     print("请不要输入负数")
# else:
#     new_index = index if index < len(words) else len(words)-1
#     print(f"对应位置的字符是: {words[new_index]}")
