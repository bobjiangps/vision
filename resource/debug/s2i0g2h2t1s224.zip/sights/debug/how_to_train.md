#### Training is required to activated sights repo for running UI auto test with AI.
#### This article shares how to train images and how to evaluate data.
<hr>

**1. Capture images with targets**

Use any screen capture tool to draw region and save to one folder. suggest to capture image which height and width is multiple of 32.

To make the training for all images smoothly, we can agree on some standards.

> Standard 1: capture image with the same height and width.

> Standard 2: the height and width is set to between 480 to 512.

> Standard 3: there should be at least one element on the image.

> Standard 4: at least one hundred images for each type. the more, the better. 
<hr>

**2. Label targets**

Clone repo from [labelImg](https://github.com/tzutalin/labelImg), follow readme to install dependencies.

Modify /data/predefined_classes.txt, replace the content with your element types.

Run 'python labelImg.py' to launch the application.

Switch the format to 'YOLO'.

Open dir which you save images.

Click 'Create RectBox', draw region of elements, save. the tool will generate txt file with same name as image. keep the txt files. keep the classes.txt as well.

![labelimg sample](https://raw.githubusercontent.com/tzutalin/labelImg/master/demo/demo3.jpg)
<hr>

**3. Organize images**

copy images and txt files to new folder as following structure:
image files store in images folder, txt files store in labels folder.

    -trainDataset
      -train
        -images
        -labels
      -valid
        -images
        -labels
      data.yaml
     
the sample of data.yaml is:

    train: ./trainDataset/train/images
    val: ./trainDataset/valid/images
    nc: 1
    names: [ 'button']
    
<hr>

**4. Train images**

Clone repo from [yolov5](https://github.com/ultralytics/yolov5), follow readme to install dependencies.

run command as example:

    python train.py --img 500 --batch 16 --epochs 100 --data './trainDataset-active4/data.yaml' --cfg ./models/yolov5s.yaml --weights '' --name activeyolo5s_results --cache


    - img: size of images
    - batch: size of data provided each time
    - epochs: like sprint
    - data: config file of datasets
    - cfg: config file to describe how to train
    - weights: define final model
    - name: folder to store data during training
    * notice: sometimes we need to define our own neural network for cfg parameter to get better results
    
<hr>

**5. Evaluate data**

During the training process, we can see log as below, please watch the four indicators:
  
    - P
    - R
    - mAP@.5 
    - mAP@.5:.95
    - iou is another important indicator but not presented here
    
1 is perfect. The closer, the better.

for example:

         Epoch   gpu_mem       box       obj       cls     total    labels  img_size
     99/99        0G   0.04662   0.03291  0.002912   0.08244        34       512: 100%|██████████████| 10/10 [02:02<00:00, 12.22s/it]
               Class     Images     Labels          P          R     mAP@.5 mAP@.5:.95: 100%|██████████| 1/1 [00:02<00:00,  2.34s/it]
              button         10         14          1       0.92      0.972      0.585

<hr>

**6. Upload images if result is good**

If you capture enough images and get good training result, please upload to [datasets repo](https://gitlab.dev.activenetwork.com/GlobalAutomation/framework3_dl/datasets) for normalization and finalization.

for example, the dataset for checkbox will be uploaded to checkbox folder, the name format can be: checkbox_timestamp.png.

Just focus on improving datasets if you are working on training task.

    *notice: the intermediate file generated cannot be applied to sights repo.


