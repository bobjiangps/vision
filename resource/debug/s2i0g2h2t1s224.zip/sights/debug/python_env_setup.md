## Installation
#### Mac
recommend to use pyenv.
install pyenv:
> * brew install pyenv 

add following config in ~/.bash_profile:
> * export PYENV_ROOT=/usr/local/var/pyenv
if which pyenv > /dev/null; then eval "$(pyenv init -)"; fi

then reopen terminal to check with following commands:
> * pyenv install -l (list available versions)
> * pyenv install 3.8.10  (install python by version)
> * pyenv global 3.8.10  (switch global python version)

#### Win
go to python official site to download installer: https://www.python.org/downloads/
then run the installer on windows.

recommend to use python >= 3.8. but if you will work on AI tasks, DO NOT use the latest version of python.

## Virtual Environment
we can use virtual environment to install 3rd libraries for each project to avoid conflict.
> * pip install virtualenv

activate:
> * virtualenv venv  ('venv' means name, we can give any name you prefer)

> * source venv/bin/activate (mac)
> * venv\Scripts\activate.bat (win)

then install any library into this virtual environment.

deactivate:
> * deactivate (mac)
> * venv\Scripts\deactivate.bat (win)

## IDE
recommend to use Pycharm: https://www.jetbrains.com/pycharm/download/ 
or use VSCode + python plugin