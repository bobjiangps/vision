import glob
import os
import cv2
import numpy as np
from pathlib import Path
from sights.lib.visual.augment import letterbox


class LoadImages:
    def __init__(self, path, img_size=640, stride=32):
        p = str(Path(path).absolute())
        if '*' in p:
            files = sorted(glob.glob(p, recursive=True))
        elif os.path.isdir(p):
            files = sorted(glob.glob(os.path.join(p, '*.*')))
        elif os.path.isfile(p):
            files = [p]
        else:
            raise Exception(f'ERROR: {p} does not exist')
        img_formats = ['bmp', 'jpg', 'jpeg', 'png', 'tif', 'tiff', 'dng', 'webp', 'mpo']
        images = [x for x in files if x.split('.')[-1].lower() in img_formats]
        self.img_size = img_size
        self.stride = stride
        self.files = images
        self.nf = len(images)
        self.mode = 'image'
        assert self.nf > 0, f'No images or videos found in {p}. ' \
                            f'Supported formats are:\nimages: {img_formats}\nvideos: {vid_formats}'

    def __iter__(self):
        self.count = 0
        return self

    def __next__(self):
        if self.count == self.nf:
            raise StopIteration
        path = self.files[self.count]

        self.count += 1
        img0 = cv2.imread(path)
        img0 = img0[:, 200:-200]
        assert img0 is not None, 'Image Not Found ' + path

        img = letterbox(img0, self.img_size, stride=self.stride)[0]
        img = img.transpose((2, 0, 1))[::-1]
        img = np.ascontiguousarray(img)

        return path, img, img0

    def __len__(self):
        return self.nf
