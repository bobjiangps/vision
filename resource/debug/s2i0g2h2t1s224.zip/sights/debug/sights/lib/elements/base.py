from sights.conf.default import *
import copy


class ElementBase:
    _action = None
    _offset = [0, 0]

    def __init__(self, text=None, element_type=None, keyword=None, direction=None, beyond=True, ref_name=None):
        self.text = text
        self.element_type = element_type
        self.keyword = keyword
        self.direction = direction
        self.beyond = beyond
        self.ref_name = ref_name
        self.visual_element = None  # store located visual element
        self.index = 0  # element index of elements()

    @classmethod
    def _set_action(cls, action):
        cls._action = action

    @classmethod
    def _set_offset(cls, offset):
        cls._offset = offset

    def wait_element_visible(self, timeout=default_timeout):
        self.relocate(timeout)
        return self

    def wait_element_invisible(self, timeout=default_timeout):
        if self.ref_name is None:
            self._action.wait_until_disappear(self, timeout)
        else:
            self._action.wait_until_region_element_disappear(self, timeout)
        self.visual_element = None
        return self

    def elements(self, timeout=default_timeout):
        results = []
        visual_elements = self.locate(True, timeout)
        for index, visual in enumerate(visual_elements):
            copy_element = copy.deepcopy(self)
            copy_element.visual_element = visual
            copy_element.index = index
            results.append(copy_element)
        return results

    def element(self, timeout=default_timeout):
        self.visual_element = self.locate(False, timeout)
        return self

    def locate(self, find_elements, timeout=default_timeout):
        if find_elements:
            return self._action.wait_until_elements_display(self, timeout)
        else:
            if self.ref_name is None:
                visual = self._action.wait_until_display(self, timeout)
            else:
                visual = self._action.wait_until_region_element_display(self, timeout)
            return visual

    def relocate(self, timeout=default_timeout):
        # if action called from a element returned from elements() method, then relocate its visual element
        if self.visual_element and self.index > 0:
            self.visual_element = self.locate(True, timeout)[self.index]
        else:
            self.element(timeout)  # locate element before any action to avoid stale element

    def before_action(self):
        self.relocate()

    def action_click(self, relocate=True):
        if relocate:
            self.before_action()
        self._action.click(
            (self.visual_element.location.x + self._offset[0], self.visual_element.location.y + self._offset[1]))
        return self

    def action_input(self, value, relocate=True):
        if relocate:
            self.before_action()
        self._action.input(
            (self.visual_element.location.x + self._offset[0], self.visual_element.location.y + self._offset[1]), value)
        return self

    def action_clear(self, relocate=True):
        if relocate:
            self.before_action()
        self._action.clear(
            (self.visual_element.location.x + self._offset[0], self.visual_element.location.y + self._offset[1]))
        return self

    def action_press_key(self, key, relocate=True):
        if relocate:
            self.before_action()
        self._action.press_key(
            (self.visual_element.location.x + self._offset[0], self.visual_element.location.y + self._offset[1]), key)
        return self

    def action_send_value(self, value, relocate=True):
        if relocate:
            self.before_action()
        self._action.send_value(
            (self.visual_element.location.x + self._offset[0], self.visual_element.location.y + self._offset[1]), value)
        return self

    def is_visible(self):
        return self._action.is_displayed(self)

    def is_exist(self):
        return self._action.is_displayed(self)

    def click(self, *args):
        self.action_click()
