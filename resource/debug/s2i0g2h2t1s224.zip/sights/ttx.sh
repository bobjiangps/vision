while read LINE; do
  echo ${LINE}    # do something with it here
  echo "================="
  echo ${LINE//\n/}
  arr= (${LINE//\n/})
  for a in ${arr[@]}
  do
    echo ${a}
  done
done

exit 0
