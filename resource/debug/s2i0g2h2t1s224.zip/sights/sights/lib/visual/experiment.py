import torch
import torch.nn as nn
from sights.conf.config import LoadConfig


class Ensemble(nn.ModuleList):
    def __init__(self):
        super(Ensemble, self).__init__()

    def forward(self, x, augment=False, profile=False, visualize=False):
        y = []
        for module in self:
            y.append(module(x, augment, profile, visualize)[0])
        y = torch.cat(y, 1)
        return y, None


def load(weights, map_location=None):
    model = Ensemble()
    try:
        ckpt = torch.load(weights, map_location=map_location)
        model.append(ckpt['ema' if ckpt.get('ema') else 'model'].float().fuse().eval())
    except KeyError:
        from sights.lib.visual.model import Model
        ckpt = Model(LoadConfig(), 3, 12, None).to(map_location)
        ckpt.load_state_dict(torch.load(weights))
        ckpt.fuse().eval()
        model[0] = ckpt
    if len(model) == 1:
        return model[-1]
    else:
        for k in ['names']:
            setattr(model, k, getattr(model[-1], k))
        model.stride = model[torch.argmax(torch.tensor([m.stride.max() for m in model])).int()].stride
        return model
