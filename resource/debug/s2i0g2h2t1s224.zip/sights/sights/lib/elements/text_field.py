from sights.lib.elements.base import ElementBase
import re


class TextField(ElementBase):
    
    def __init__(self, keyword=None, direction=None, ref_name=None):
        super().__init__()
        self.keyword = keyword
        self.direction = direction
        self.ref_name = ref_name
        self.element_type = "_".join(re.findall("[A-Z][^A-Z]*", self.__class__.__mro__[-3].__qualname__))

    def input(self, value, *args):
        if value:
            self.action_input(value)

    def clear(self, *args):
        self.action_clear()
