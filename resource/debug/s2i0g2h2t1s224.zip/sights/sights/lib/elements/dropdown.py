from sights.lib.elements.base import ElementBase


class Dropdown(ElementBase):

    def __init__(self, keyword=None, direction=None, ref_name=None):
        super().__init__()
        self.keyword = keyword
        self.direction = direction
        self.ref_name = ref_name
        self.element_type = self.__class__.__mro__[-3].__qualname__

    def select_item(self, name, *args):
        self.action_click()
        item = self._action.common_option_legacy_element(name)
        if item:
            item.click()
        else:
            self.action_send_value(name.lower(), relocate=False)
            self.action_press_key("enter", relocate=False)
