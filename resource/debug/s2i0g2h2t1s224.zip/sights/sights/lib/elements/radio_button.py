from sights.lib.elements.base import ElementBase
import re


class RadioButton(ElementBase):
    
    def __init__(self, keyword=None, direction="Left", ref_name=None):
        super().__init__()
        self.keyword = keyword
        self.direction = direction
        self.ref_name = ref_name
        self.element_type = "_".join(re.findall("[A-Z][^A-Z]*", self.__class__.__mro__[-3].__qualname__))

    def select(self, *args):
        if self.is_selected() is False:
            self.click()

    def unselect(self, *args):
        if self.is_selected():
            self.click()
