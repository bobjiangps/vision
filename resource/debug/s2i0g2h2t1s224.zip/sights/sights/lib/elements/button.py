from sights.lib.elements.base import ElementBase


class Button(ElementBase):
    
    def __init__(self, keyword=None, ref_name=None):
        super().__init__()
        self.keyword = keyword
        self.element_type = self.__class__.__mro__[-3].__qualname__
        self.beyond = False
        self.ref_name = ref_name
