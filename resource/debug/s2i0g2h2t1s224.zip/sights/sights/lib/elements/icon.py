from sights.lib.elements.base import ElementBase


class Icon(ElementBase):

    def __init__(self, category, keyword=None, ref_name=None):
        super().__init__()
        self.element_type = self.__class__.__mro__[-3].__qualname__
        self.category = category
        self.ref_name = ref_name
        if not keyword:
            self.beyond = False
        else:
            self.keyword = keyword
