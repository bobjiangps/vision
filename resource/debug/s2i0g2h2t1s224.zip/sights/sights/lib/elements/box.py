from sights.lib.elements import *
from sights.conf.default import *
import importlib

# example:

# Box("Sign in").TextField("Enter your Login name").input("jbc")
# box = Box("Sign in")
# box.TextField("Login name", direction="down").input("jbc")
# box.Button("Sign in").click(3)
# box_element = box.element(3)
# box_visual_element = box_element.visual_element
# child_element = box.TextField("Password").element(3)
# child_visual_element = child_element.visual_element

class Box(ElementBase):
    _module_locators = importlib.import_module('sights.lib.elements')

    def __init__(self, ref_name, location_only=False):
        super().__init__()
        self.location_only = location_only
        self.ref_name = ref_name
        self.element_type = self.__class__.__mro__[-3].__qualname__

    # note: child element under box must be the classes defined under sights.lib.elements, e.g TextField, Button and so on
    def __getattr__(self, name):
        def child_element(*args, **kwargs):
            f_args = {**kwargs, **{"ref_name": self.ref_name}}
            class_ = getattr(self._module_locators, name)
            instance = class_(*args, **f_args)
            return instance

        return child_element

    # TODO: only support element return by now
    def elements(self, timeout=default_timeout):
        return self.element(default_timeout)

    # region location, format: ((x1,y1),(x2,y2))
    def location(self, timeout=default_timeout):
        self.location_only = True
        location = self._action.wait_until_region_element_display(self, timeout)
        self.location_only = False
        return location


