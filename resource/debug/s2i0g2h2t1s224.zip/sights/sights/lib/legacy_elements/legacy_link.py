"""
@feature: 
@author: Francis Zhang
@date: 2022/1/12
"""
from sights.lib.legacy_elements.base import LegacyElementBase


class LegacyLink(LegacyElementBase):
    """
    standard link component
    """
    
    def click(self):
        """
        click link
        """
        self.wait_element_visible()
        self._action.legacy_click(self.element())
