"""
@feature: 
@author: Francis Zhang
@date: 2022/1/12
"""
from sights.lib.legacy_elements.base import LegacyElementBase


class LegacyText(LegacyElementBase):
    """
    standard text component
    """
    
    def input(self, value: str, method: str = 'normal'):
        """
        input text
        """
        self.wait_element_visible()
        self._action.legacy_input(self.element(), value)

    def clear(self, value: str, method: str = 'normal'):
        """
        clear text
        """
        self.wait_element_visible()
        self._action.legacy_clear(self.element())
