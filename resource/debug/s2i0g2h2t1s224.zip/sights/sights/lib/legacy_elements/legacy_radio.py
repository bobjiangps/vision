"""
@feature: 
@author: Francis Zhang
@date: 2022/1/12
"""
from sights.lib.legacy_elements.base import LegacyElementBase


class LegacyRadio(LegacyElementBase):
    """
    standard radio button component
    """
    
    def select(self):
        """
        select radio button
        """
        self.wait_element_visible()
        if not self._action.legacy_is_selected(self.element()):
            self._action.legacy_click(self.element())
    
    def is_selected(self):
        """
        check if radio button selected or not
        """
        self.wait_element_visible()
        return self._action.legacy_is_selected(self.element())
