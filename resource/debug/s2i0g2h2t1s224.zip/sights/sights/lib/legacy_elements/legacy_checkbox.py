"""
@feature: 
@author: Francis Zhang
@date: 2022/1/12
"""
from sights.lib.legacy_elements.base import LegacyElementBase


class LegacyCheckbox(LegacyElementBase):
    """
    standard checkbox component
    """
    
    def select(self):
        """
        select checkbox
        """
        self.wait_element_visible()
        if not self._action.legacy_is_selected(self.element()):
            self._action.legacy_click(self.element())
    
    def unselect(self):
        """
        unselect checkbox
        """
        self.wait_element_visible()
        if self._action.legacy_is_selected(self.element()):
            self._action.legacy_click(self.element())

    def is_selected(self):
        """
        check if checkbox selected or not
        """
        self.wait_element_visible()
        return self._action.legacy_is_selected(self.element())
