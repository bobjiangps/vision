"""
@feature: 
@author: Francis Zhang
@date: 2022/1/12
"""
from sights.conf.default import *


class LegacyElementBase:
    """
    standard element base
    """

    _action = None

    def __init__(self, by, value):
        self.by = by
        self.value = value

    @classmethod
    def _set_action(cls, action):
        cls._action = action

    def element(self):
        """
        fetch first raw element
        """
        return self._action.legacy_find_element(self.by, self.value)

    def elements(self):
        """
        fetch all raw elements
        """
        return self._action.legacy_find_elements(self.by, self.value)
    
    def locator(self):
        """
        fetch locator
        """
        return self.by, self.value
    
    def is_exist(self):
        """
        check if element exists or not
        """
        pass
    
    def is_visible(self):
        """
        check if element is visible or not
        """
        e = self.element()
        if e is None:
            return
        return self._action.legacy_is_displayed(e)
    
    def focus(self):
        """
        set focus on current element
        """
        pass
    
    def lose_focus(self):
        """
        lose focus on current element
        """
        pass
    
    def wait_element_visible(self, timeout=default_timeout):
        """
        wait until element visible
        """
        return self._action.legacy_wait_until_element_display(self.locator(), timeout)
    
    def wait_element_invisible(self, timeout=default_timeout):
        """
        wait until element invisible
        """
        return self._action.legacy_wait_until_element_disappear(self.locator(), timeout)
