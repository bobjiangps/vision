"""
@feature: 
@author: Francis Zhang
@date: 2022/1/11
"""
from sights.lib.legacy_elements.base import LegacyElementBase


class LegacyButton(LegacyElementBase):
    """
    standard button component
    """
    
    def click(self):
        """
        click button
        """
        self.wait_element_visible()
        self._action.legacy_click(self.element())
