"""
@feature: 
@author: Francis Zhang
@date: 2022/1/12
"""
from sights.lib.legacy_elements.base import LegacyElementBase


class LegacyTable(LegacyElementBase):
    """
    standard table component
    """
    
    def get_table_info(self):
        """
        fetch table info
        """
        pass
