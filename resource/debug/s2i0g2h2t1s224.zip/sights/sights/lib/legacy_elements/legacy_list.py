"""
@feature: 
@author: Francis Zhang
@date: 2022/1/12
"""
from sights.lib.legacy_elements.base import LegacyElementBase
from sights.lib.support.exceptions import NotFoundException


class LegacyList(LegacyElementBase):
    """
    standard dropdown list component
    """
    
    def select_item(self, val: str, by: str = 'text'):
        """
        select item by specified content
        """
        self.wait_element_visible()
        options = self.element().find_elements_by_tag_name('option')
        for option in options:
            if option.text == val:
                option.click()
                break
        else:
            raise NotFoundException(f"Item not found: {val}")

    def get_selected_item(self):
        """
        fetch selected item
        """
        item = None
        self.wait_element_visible()
        options = self.get_all_items()
        for option in options:
            if option.is_selected():
                item = option.text
                break
        return item
    
    def get_all_items(self):
        """
        fetch all list items
        """
        items = []
        self.wait_element_visible()
        options = self.element().find_elements_by_tag_name('option')
        for option in options:
            items.append(option.text)
        return items
    
    def is_item_selected(self, val: str, by: str = 'text'):
        """
        check if specified item selected or not
        """
        self.wait_element_visible()
        item = self.get_selected_item()
        if item == val:
            return True
        else:
            return False
