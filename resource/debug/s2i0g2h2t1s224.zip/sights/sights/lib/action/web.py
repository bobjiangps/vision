from sights.lib.support.custom_wait import CustomWait
from sights.lib.support.expected import *
from sights.conf.default import *
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.common.exceptions import MoveTargetOutOfBoundsException, StaleElementReferenceException, NoSuchElementException
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from sights.utils.selenium_utils import SeleniumUtils
from sights.lib.visual.gradual import Grad
import platform


class WebAction(CustomWait):

    def __init__(self, driver, models, logger, timeout=default_timeout):
        super().__init__(driver, timeout)
        self._model = models
        self.action_chains = ActionChains(self._driver)
        self.action_builder = ActionBuilder(self._driver)
        self.log = logger
        self.timeout = timeout
        self.webdriver_wait = WebDriverWait(self._driver, self.timeout)

    def wait_until_display(self, instance, timeout=default_timeout):
        if instance.beyond:
            return self.wait_until_element_match(instance, timeout)
        else:
            if instance.text:
                return self.wait_until_text_display(instance.text, timeout)
            else:
                return self.wait_until_element_display(instance, timeout)

    def wait_until_disappear(self, instance, timeout=default_timeout):
        if instance.beyond:
            return self.wait_until_element_match_disappear(instance, timeout)
        else:
            if instance.text:
                return self.wait_until_text_disappear(instance.text, timeout)
            else:
                return self.wait_until_element_disappear(instance, timeout)

    def wait_until_text_display(self, text, timeout=default_timeout):
        self.log.info(f"Wait the text [{text}] to display")
        return self.until(TextDisplayOnPage(text), f"cannot see --{text}-- on page after wait {timeout} seconds") \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until(TextDisplayOnPage(text), f"cannot see --{text}-- on page")

    def wait_until_text_disappear(self, text, timeout=default_timeout):
        self.log.info(f"Wait the text [{text}] to disappear")
        return self.until_not(TextDisplayOnPage(text), f"The text --{text}-- still display on page after wait {timeout} seconds") \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until_not(TextDisplayOnPage(text), f"cannot see --{text}-- on page")

    def wait_until_element_display(self, instance, timeout=default_timeout):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        element = instance.category if hasattr(instance, "category") else instance.element_type
        keyword = instance.keyword
        message = f"cannot see --{element}-- on page after wait {timeout} seconds"
        if keyword:
            message += f" with keyword --{keyword}--"
            self.log.info(f"Wait the element [{element}] identified by [{keyword}] to display")
        else:
            self.log.info(f"Wait the element [{element}] to display")
        return self.until(ElementDisplayOnPage(model, element, keyword), message) \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until(ElementDisplayOnPage(model, element, keyword), message)

    def wait_until_elements_display(self, instance, timeout=default_timeout):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        element = instance.category if hasattr(instance, "category") else instance.element_type
        keyword = instance.keyword
        message = f"cannot see --{element}-- on page after wait {timeout} seconds"
        if instance.beyond:
            self.log.info(f"Wait the elements [{element}] to display")
            direction = instance.direction
            return self.until(ElementMatchOnPage(model, element, keyword, direction, is_detect_all=True), message) \
                if timeout == self.timeout else \
                CustomWait(self._driver, timeout).until(ElementMatchOnPage(model, element, keyword, direction, is_detect_all=True), message)
        else:
            if instance.text is not None:
                self.log.info(f"Wait the texts [{instance.text}] to display")
                return self.until(TextDisplayOnPage(instance.text, is_detect_all=True), message) \
                    if timeout == self.timeout else \
                    CustomWait(self._driver, timeout).until( TextDisplayOnPage(instance.text, is_detect_all=True), message)
            else:
                self.log.info(f"Wait the elements [{element}] to display")
                return self.until(ElementDisplayOnPage(model, element, keyword, is_detect_all=True), message) \
                    if timeout == self.timeout else \
                    CustomWait(self._driver, timeout).until(ElementDisplayOnPage(model, element, keyword, is_detect_all=True), message)

    def find_ref_element_from_elements(self, instance, ref_name=None, ref_direct="down", timeout=default_timeout):
        ref_element = self.wait_until_text_display(ref_name, timeout)
        target_elements = self.wait_until_elements_display(instance, timeout)
        if ref_direct == "down":
            sorted_target_elements = sorted(target_elements, key=lambda k: (k[1], k[0]))
        elif ref_direct == "up":
            sorted_target_elements = sorted(target_elements, key=lambda k: (k[1], k[0]), reverse=True)
        elif ref_direct == "right":
            sorted_target_elements = sorted(target_elements, key=lambda k: (k[0], k[1]))
        elif ref_direct == "left":
            sorted_target_elements = sorted(target_elements, key=lambda k: (k[0], k[1]), reverse=True)
        for r in sorted_target_elements:
            if ref_direct == "down":
                if ref_element[1] <= r[1]:
                    return r
            elif ref_direct == "up":
                if ref_element[1] > r[1]:
                    return r
            elif ref_direct == "right":
                if ref_element[0] <= r[0]:
                    return r
            elif ref_direct == "left":
                if ref_element[0] > r[0]:
                    return r
        return False

    def wait_until_element_disappear(self, instance, timeout=default_timeout):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        element = instance.category if hasattr(instance, "category") else instance.element_type
        keyword = instance.keyword
        message = f"The element --{element}-- still display on page after wait {timeout} seconds"
        if keyword:
            message += f" with keyword --{keyword}--"
            self.log.info(f"Wait the element [{element}] identified by [{keyword}] to disappear")
        else:
            self.log.info(f"Wait the element [{element}] to disappear")
        return self.until_not(ElementDisplayOnPage(model, element, keyword), message) \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until_not(ElementDisplayOnPage(model, element, keyword), message)

    def wait_until_element_match(self, instance, timeout=default_timeout):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        element = instance.category if hasattr(instance, "category") else instance.element_type
        keyword = instance.keyword
        direction = instance.direction
        self.wait_until_text_display(keyword, timeout)
        message = f"cannot see --{element}-- on page with keyword --{keyword}-- after wait {timeout} seconds"
        self.log.info(f"Wait the element [{element}] which match [{keyword}] to display")
        return self.until(ElementMatchOnPage(model, element, keyword, direction), message) \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until(ElementMatchOnPage(model, element, keyword, direction), message)

    def wait_until_element_match_disappear(self, instance, timeout=default_timeout):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        element = instance.category if hasattr(instance, "category") else instance.element_type
        keyword = instance.keyword
        direction = instance.direction
        message = f"The element --{element}-- still display on page with keyword --{keyword}-- after wait {timeout} seconds"
        self.log.info(f"Wait the element [{element}] which match [{keyword}] to disappear")
        return self.until_not(ElementMatchOnPage(model, element, keyword, direction), message) \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until_not(ElementMatchOnPage(model, element, keyword, direction), message)

    def wait_until_region_element_display(self, instance, timeout=default_timeout):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        instance.element_type = instance.category if hasattr(instance, "category") \
                                                     and instance.element_type.lower() != 'box' else instance.element_type
        message = f"cannot see --{instance.element_type}-- on page after wait {timeout} seconds"
        location_only = instance.location_only if hasattr(instance, "location_only") else False
        if instance.keyword:
            keyword = instance.keyword
            message += f" with keyword --{instance.keyword}--"
            self.log.info(f"Wait the element [{instance.element_type}] identified by [{instance.keyword}] to display")
        else:
            keyword = instance.text
            self.log.info(f"Wait the element [{instance.element_type}] identified by [{instance.text}] to display")
        return self.until(
            RegionElementOrTextDisplayOnPage(model, instance.element_type, keyword=keyword, ref_name=instance.ref_name,
                                             beyond=instance.beyond, direction=instance.direction,
                                             location_only=location_only), message) \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until(
                RegionElementOrTextDisplayOnPage(model, instance.element_type, keyword=keyword,
                                                 ref_name=instance.ref_name, beyond=instance.beyond,
                                                 direction=instance.direction, location_only=location_only), message)

    def wait_until_region_element_disappear(self, instance, timeout=default_timeout):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        instance.element_type = instance.category if hasattr(instance, "category") \
                                                     and instance.element_type.lower() != 'box' else instance.element_type
        message = f"The element --{instance.element_type}-- still display on page after wait {timeout} seconds"
        location_only = instance.location_only if hasattr(instance, "location_only") else False
        if instance.keyword:
            keyword = instance.keyword
            message += f" with keyword --{instance.keyword}--"
            self.log.info(f"Wait the element [{instance.element_type}] identified by [{instance.keyword}] to disappear")
        else:
            keyword = instance.text
            self.log.info(f"Wait the element [{instance.element_type}] identified by [{instance.text}] to disappear")
        return self.until_not(
            RegionElementOrTextDisplayOnPage(model, instance.element_type, keyword=keyword, ref_name=instance.ref_name,
                                             beyond=instance.beyond, direction=instance.direction,
                                             location_only=location_only), message) \
            if timeout == self.timeout else \
            CustomWait(self._driver, timeout).until_not(
                RegionElementOrTextDisplayOnPage(model, instance.element_type, keyword=keyword,
                                                 ref_name=instance.ref_name, beyond=instance.beyond,
                                                 direction=instance.direction, location_only=location_only), message)

    def click(self, point):
        self.log.info("Perform click on the element")
        self.action_builder.pointer_action.move_to_location(point[0], point[1])
        self.action_builder.pointer_action.click()
        self.action_builder.perform()
        self.clear_actions(self.action_builder)

    def input(self, point, value):
        self.log.info(f"Input [{value}] to the element")
        self.action_builder.pointer_action.move_to_location(point[0], point[1])
        self.action_builder.pointer_action.click()
        self.action_builder.perform()
        self.clear_actions(self.action_builder)
        try:
            if platform.system() == "Darwin":
                self.action_chains.key_down(Keys.COMMAND).key_down('a').key_up(Keys.COMMAND).key_up('a').perform()
            else:
                self.action_chains.key_down(Keys.CONTROL).key_down('a').key_up(Keys.CONTROL).key_up('a').perform()
            self.action_chains.send_keys(value).perform()
        except StaleElementReferenceException:
            element = self._driver.execute_script(f"return document.elementFromPoint({point[0]}, {point[1]});")
            if platform.system() == "Darwin":
                element.send_keys(Keys.COMMAND + "a", Keys.BACKSPACE)
            else:
                element.send_keys(Keys.CONTROL + "a", Keys.BACKSPACE)
            element.send_keys(value)
        self.clear_actions(self.action_chains)

    def clear(self, point):
        self.log.info(f"Clear the element")
        self.action_builder.pointer_action.move_to_location(point[0], point[1])
        self.action_builder.pointer_action.click()
        self.action_builder.perform()
        self.clear_actions(self.action_builder)
        if platform.system() == "Darwin":
            self.action_chains.key_down(Keys.COMMAND).key_down('a').key_up(Keys.COMMAND).key_up('a').send_keys(Keys.BACKSPACE).perform()
        else:
            self.action_chains.key_down(Keys.CONTROL).key_down('a').key_up(Keys.CONTROL).key_up('a').send_keys(Keys.BACKSPACE).perform()
        self.clear_actions(self.action_chains)

    def send_value(self, point, value):
        self.log.info(f"Send [{value}] to the element")
        self.action_builder.pointer_action.move_to_location(point[0], point[1])
        self.action_builder.perform()
        self.clear_actions(self.action_builder)
        self.action_chains.send_keys(value).perform()
        self.clear_actions(self.action_chains)

    def press_key(self, point, key):
        keys = {
            "enter": Keys.ENTER,
            "down": Keys.DOWN,
            "up": Keys.UP,
            "back": Keys.BACK_SPACE
        }
        if key.lower() not in keys.keys():
            self.log.info(f"key [{key}] not supported yet")
        else:
            self.log.info(f"press key [{key}] to the element")
            self.action_builder.pointer_action.move_to_location(point[0], point[1])
            self.action_builder.perform()
            self.action_chains.send_keys(keys[key]).perform()
            self.clear_actions(self.action_chains)

    def is_displayed(self, instance):
        if isinstance(self._model, list):
            model = self._model[1] if hasattr(instance, "category") else self._model[0]
        else:
            model = self._model
        element = instance.category if hasattr(instance, "category") else instance.element_type
        if instance.beyond:
            return ElementMatchOnPage(model, element, instance.keyword, instance.direction)(self._driver)
        else:
            if instance.text:
                return TextDisplayOnPage(instance.text)(self._driver)
            else:
                return ElementDisplayOnPage(model, element, instance.keyword)(self._driver)

    def is_selected(self, border):
        self.log.info("check selected or not")
        p, n = Grad.narrow(border)
        return (p > n).all()

    def scroll_to_bottom(self):
        self._driver.execute_script("window.scrollBy(0,document.body.scrollHeight);")

    def scroll_to_top(self):
        self._driver.execute_script("window.scrollTo(0, 0);")

    def scroll_by(self, x=0, y=500):
        self._driver.execute_script(f"window.scrollBy({x}, {y});")

    @staticmethod
    def clear_actions(item):
        if hasattr(item, "w3c_actions"):
            for device in item.w3c_actions.devices:
                device.clear_actions()
        else:
            for device in item.devices:
                device.clear_actions()

    def browse_page(self, url):
        self.log.info(f"Browser page {url}")
        self._driver.get(url)

    def restart_browser(self, url=None):
        self.log.info(f"Restart browser")
        self._driver = SeleniumUtils.restart_driver()
        if url:
            self.browse_page(url)

    def check_offset(self):
        v_size = BaseExpectation.get_viewport_size(self._driver)
        b_size = BaseExpectation.get_body_size(self._driver)
        body = self._driver.find_element_by_tag_name("body")
        x = 0
        y = 0
        if v_size[1] != b_size[1]:
            while True:
                try:
                    ActionChains(self._driver).move_to_element_with_offset(body, x, y).click().perform()
                    ActionChains(self._driver).reset_actions()
                    break
                except MoveTargetOutOfBoundsException:
                    y += 10
        return [x, y], body

    def legacy_wait_until_element_display(self, element_locator, timeout=default_timeout):
        self.log.info(f"Wait the element identified by {element_locator} to display in {timeout} seconds")
        return self.webdriver_wait.until(EC.presence_of_element_located(element_locator)) \
            if timeout == self.timeout else \
            WebDriverWait(self._driver, timeout).until(EC.presence_of_element_located(element_locator))

    def legacy_wait_until_element_disappear(self, element_locator, timeout=default_timeout):
        self.log.info(f"Wait the element identified by {element_locator} to disappear in {timeout} seconds")
        return self.webdriver_wait.until_not(EC.presence_of_element_located(element_locator)) \
            if timeout == self.timeout else \
            WebDriverWait(self._driver, timeout).until_not(EC.presence_of_element_located(element_locator))

    def legacy_wait_until_element_clickable(self, element_locator, timeout=default_timeout):
        self.log.info(f"Wait the element identified by {element_locator} to be clickable in {timeout} seconds")
        return self.webdriver_wait.until(EC.element_to_be_clickable(element_locator)) \
            if timeout == self.timeout else \
            WebDriverWait(self._driver, timeout).until(EC.element_to_be_clickable(element_locator))

    def legacy_find_element(self, element_type, element_value):
        try:
            return self._driver.find_element(element_type, element_value)
        except NoSuchElementException as e:
            return None

    def legacy_find_elements(self, element_type, element_value):
        return self._driver.find_elements(element_type, element_value)

    def legacy_is_displayed(self, element):
        return element.is_displayed()

    def legacy_is_enabled(self, element):
        return element.is_enabled()

    def legacy_is_selected(self, element):
        return element.is_selected()

    def legacy_get_location(self, element):
        return element.location

    def legacy_get_text(self, element):
        return element.text

    def legacy_get_attribute(self, element, name):
        return element.get_attribute(name)

    def legacy_input(self, element, text):
        self.legacy_clear(element)
        element.send_keys(text)

    def legacy_clear(self, element):
        element.clear()

    def legacy_click(self, element, method="normal"):
        if method == "normal":
            element.click()
        else:
            self._driver.execute_script("return arguments[0].click()", element)

    def legacy_screenshot(self, element, filename):
        element.screenshot(filename)

    def common_option_legacy_element(self, name):
        e = self.legacy_find_elements("xpath", f"//ul[contains(@class, 'show')]//*[text()='{name}']")
        return e[0] if len(e) > 0 else None
