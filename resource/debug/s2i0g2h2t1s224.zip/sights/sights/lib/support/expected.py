from sights.lib.visual.imager import Imager
from sights.lib.visual.common import center, proportion
from sights.lib.visual.pred import predict
from sights.conf.config import LoadConfig
from sights.lib.support.deviation import *
from sights.lib.support.visual_element import VisualElement
from pathlib import Path
import base64
import json


class BaseExpectation:
    NEED_FULL_PAGE_SCAN = False

    def __init__(self):
        self._img = str(Path.cwd().joinpath("resource", "img", f"{LoadConfig().model['img']}.png"))
        self._img_shape = None

    @staticmethod
    def is_in_iframe(driver):
        """
        if in iframe will return 1 else return 0
        """
        return driver.execute_script("return window.location !== window.parent.location ? 1 : 0;")

    @staticmethod
    def get_viewport_size(driver):
        if BaseExpectation.is_in_iframe(driver):
            driver.switch_to.default_content()
        width = driver.execute_script("return window.innerWidth;")
        height = driver.execute_script("return window.innerHeight;")
        return [width, height]

    def __send_command(self, driver, cmd, params):
        resource = f"/session/{driver.session_id}/chromium/send_command_and_get_result"
        url = driver.command_executor._url + resource
        body = json.dumps({'cmd': cmd, 'params': params})
        response = driver.command_executor._request('POST', url, body)
        return response.get('value')

    def __evaluate(self, driver, script):
        response = self.__send_command(driver, 'Runtime.evaluate', {'returnByValue': True, 'expression': script})
        return response['result']['value']

    def capture_full_screen(self, driver):
        if hasattr(driver, 'get_full_page_screenshot_as_file'):
            driver.get_full_page_screenshot_as_file(self._img)
        else:
            if driver.name == 'firefox':
                response = driver.command_executor._request(
                    'GET',
                    driver.command_executor._url + f"/session/{driver.session_id}/moz/screenshot/full")
                with open(self._img, 'wb') as f:
                    f.write(base64.b64decode(response.get('value')))
            elif driver.name == 'chrome':
                metrics = self.__evaluate(driver, "({" + \
                                                    "width: Math.max(window.innerWidth, document.body.scrollWidth, "
                                                    "document.documentElement.scrollWidth)|0," + \
                                                    "height: Math.max(innerHeight, document.body.scrollHeight, "
                                                    "document.documentElement.scrollHeight)|0," + \
                                                    "deviceScaleFactor: window.devicePixelRatio || 1," + \
                                                    "mobile: typeof window.orientation !== 'undefined'" + \
                                                    "})")
                self.__send_command(driver, 'Emulation.setDeviceMetricsOverride', metrics)
                screenshot = self.__send_command(driver, 'Page.captureScreenshot', {'format': 'png', 'fromSurface': True})
                self.__send_command(driver, 'Emulation.clearDeviceMetricsOverride', {})
                with open(self._img, 'wb') as f:
                    f.write(base64.b64decode(screenshot['data']))
            else:
                driver.save_screenshot(self._img)


    @staticmethod
    def get_body_size(driver):
        if BaseExpectation.is_in_iframe(driver):
            driver.switch_to.default_content()
        body = driver.find_element_by_tag_name("body")
        size = body.size
        return [size["width"], size["height"]]

    def convert_location_and_sort_elements(self, elements, image_size, viewport_size, sort=True):
        for element in elements:
            point = proportion([element.location.x, element.location.y], viewport_size, image_size)
            element.location.x = point[0]
            element.location.y = point[1]
        if sort:
            return sorted(elements, key=lambda k: (k.location.y, k.location.x))
        else:
            return elements

    def element_on_image(self, image, viewport_size):
        elements = self.elements_on_image(image, viewport_size)
        if len(elements) == 0:
            return None
        else:
            return elements[0]

    def element_on_browser(self, driver):
        elements = self.elements_on_browser(driver)
        if len(elements) == 0:
            return None
        else:
            return elements[0]

    def elements_on_browser(self, driver):
        if self.NEED_FULL_PAGE_SCAN:
            self.capture_full_screen(driver)
            elements = self.elements_on_image(self._img, self.get_body_size(driver))
        else:
            driver.save_screenshot(self._img)
            elements = self.elements_on_image(self._img, self.get_viewport_size(driver))
        if len(elements) == 0:
            self.NEED_FULL_PAGE_SCAN = True
            return []
        elif self.NEED_FULL_PAGE_SCAN:
            # Not supported find_elements currently
            view_size = self.get_viewport_size(driver)
            x, y = elements[0].location.x, elements[0].location.y
            if y < view_size[1]:
                driver.execute_script(f"window.scrollTo({x}, 0);")
            elif y + view_size[1] > self.get_body_size(driver)[1]:
                driver.execute_script(f"window.scrollTo({x}, {self.get_body_size(driver)[1] - view_size[1]});")
            else:
                driver.execute_script(f"window.scrollTo({x}, {y - (view_size[1] / 2)});")
            self.NEED_FULL_PAGE_SCAN = False
            return []
        else:
            return elements


class TextDisplayOnPage(BaseExpectation):
    def __init__(self, text, is_detect_all=False):
        super().__init__()
        self.text = text
        self.is_detect_all = is_detect_all

    def elements_on_image(self, image, viewport_size, is_covert=True):
        matched_elements = []
        contours, shape = Imager.recognize_contours(image)
        ignore_case = False
        for _ in range(2):
            for c in contours:
                if ignore_case:
                    self.text = self.text.lower()
                    c = list(c)
                    c[1] = c[1].lower()
                if c[1].find(self.text.strip()) >= 0:
                    accurate_c = [p for p in c[0]]
                    width = c[0][2] - c[0][0]
                    if c[1].find(self.text.strip()) / len(c[1]) > 0.2:
                        accurate_c[0] += width * (c[1].find(self.text.strip()) / len(c[1]))
                    if (c[1].find(self.text.strip()) + len(self.text.strip())) / len(c[1]) < 0.8:
                        accurate_c[2] = c[0][0] + width * ((c[1].find(self.text.strip()) + len(self.text.strip())) / len(c[1]))
                    matched_elements.append(VisualElement(center(accurate_c), 'static', c[1]))
                elif qualified(c[1], self.text):
                    matched_elements.append(VisualElement(center(c[0]), 'static', c[1]))
            if len(matched_elements) > 0:
                break
            else:
                ignore_case = True
        words = []
        double_check = False
        if self.text.find(" ") > 0:
            words.append(self.text.split(" ")[0])
        for w in words:
            if str(contours).find(f"'{w}'") > 0:
                double_check = True
                break
        if double_check:
            contours, shape = Imager.recognize_contours(image, font="large")
            for c in contours:
                if c[1].find(self.text.strip()) >= 0:
                    matched_elements.append(VisualElement(center(c[0]), 'static', c[1]))
        self._img_shape = shape
        if is_covert:
            return self.convert_location_and_sort_elements(matched_elements, shape, viewport_size)
        else:
            return matched_elements

    def __call__(self, driver):
        return self.elements_on_browser(driver) if self.is_detect_all else self.element_on_browser(driver)


class ElementDisplayOnPage(BaseExpectation):
    def __init__(self, model, element, keyword=None, is_detect_all=False):
        super().__init__()
        self.model = model
        self.element = element.lower()
        self.keyword = keyword
        self.is_detect_all = is_detect_all

    def elements_on_image(self, image, viewport_size, is_covert=True):
        matched_elements = []
        results, labels, shape = predict(self.model, image)
        if self.element not in labels.keys():
            return []
        for r in results:
            if r["N"] == self.element:
                if self.keyword:
                    tmp = Imager.recognize_crop_contours(image, r["COOR"])
                    if tmp.find(self.keyword.strip()) >= 0 or qualified(tmp, self.keyword):
                        matched_elements.append(VisualElement(center(r["COOR"]), self.element, tmp, r["COOR"]))
                else:
                    matched_elements.append(VisualElement(center(r["COOR"]), self.element, None, r["COOR"]))
        self._img_shape = shape
        if is_covert:
            return self.convert_location_and_sort_elements(matched_elements, shape, viewport_size)
        else:
            return matched_elements

    def __call__(self, driver):
        return self.elements_on_browser(driver) if self.is_detect_all else self.element_on_browser(driver)


class ElementMatchOnPage(BaseExpectation):
    def __init__(self, model, element, keyword, direction, is_detect_all=False):
        super().__init__()
        self.model = model
        self.element = element.lower()
        self.keyword = keyword
        self.direction = direction.lower() if direction else "down"
        self.is_detect_all = is_detect_all

    def elements_on_image(self, image, viewport_size, is_covert=True):
        matched_elements = []
        matched_texts = []
        # find keywords on image
        contours, shape = Imager.recognize_contours(image)
        for c in contours:
            if c[1].find(self.keyword.strip()) >= 0 or qualified(c[1], self.keyword):
                matched_texts.append({"keyword": center(c[0]), "area": c[0], "text": c[1]})
        if len(matched_texts) == 0:
            return []
        # find elements by type
        results, labels, shape = predict(self.model, image)
        if self.element not in labels.keys():
            return []

        for match_text in matched_texts:
            match_area = match_text["area"]
            match_keyword = match_text["keyword"]
            relative_elements = {
                "up": {"area": [], "edge": [], "orientation": [], "match_orien": (match_area[0], match_area[2])},
                "down": {"area": [], "edge": [], "orientation": [], "match_orien": (match_area[0], match_area[2])},
                "left": {"area": [], "edge": [], "orientation": [], "match_orien": (match_area[1], match_area[3])},
                "right": {"area": [], "edge": [], "orientation": [], "match_orien": (match_area[1], match_area[3])}
            }
            matched_element = None
            border = None
            for r in results:
                if r["N"] == self.element:
                    if match_area[0] > r["COOR"][0] and match_area[2] < r["COOR"][2] and match_area[1] > r["COOR"][1] and match_area[3] < r["COOR"][3]:
                        self.direction = "in"
                        matched_element = center(r["COOR"])
                        border = r["COOR"]
                    if r["COOR"][3] < match_area[3] and r["COOR"][1] < match_area[1]:
                        relative_elements["up"]["area"].append(r["COOR"])
                        relative_elements["up"]["edge"].append((r["COOR"][0], r["COOR"][3], r["COOR"][2], r["COOR"][3]))
                        relative_elements["up"]["orientation"].append((r["COOR"][0], r["COOR"][2]))
                    if r["COOR"][3] > match_area[3] and r["COOR"][1] > match_area[1]:
                        relative_elements["down"]["area"].append(r["COOR"])
                        relative_elements["down"]["edge"].append((r["COOR"][0], r["COOR"][1], r["COOR"][2], r["COOR"][1]))
                        relative_elements["down"]["orientation"].append((r["COOR"][0], r["COOR"][2]))
                    if r["COOR"][2] < match_area[2] and r["COOR"][0] < match_area[0]:
                        relative_elements["left"]["area"].append(r["COOR"])
                        relative_elements["left"]["edge"].append((r["COOR"][2], r["COOR"][1], r["COOR"][2], r["COOR"][3]))
                        relative_elements["left"]["orientation"].append((r["COOR"][1], r["COOR"][3]))
                    if r["COOR"][2] > match_area[2] and r["COOR"][0] > match_area[0]:
                        relative_elements["right"]["area"].append(r["COOR"])
                        relative_elements["right"]["edge"].append((r["COOR"][0], r["COOR"][1], r["COOR"][0], r["COOR"][3]))
                        relative_elements["right"]["orientation"].append((r["COOR"][1], r["COOR"][3]))
            distance = None
            if self.direction == "in":
                matched_elements.append(VisualElement(matched_element, self.element, match_text["text"], border))
                break
            if self.is_detect_all:
                for e in relative_elements[self.direction]["area"]:
                    matched_elements.append(VisualElement(center(e), self.element, match_text["text"], e))
            else:
                for inx, e in enumerate(relative_elements[self.direction]["edge"]):
                    if (relative_elements[self.direction]["match_orien"][0] > relative_elements[self.direction]["orientation"][inx][1]) or (relative_elements[self.direction]["match_orien"][1] < relative_elements[self.direction]["orientation"][inx][0]):
                        continue
                    else:
                        position = center(e)
                        if not matched_element:
                            distance = (position[0] - match_keyword[0]) ** 2 + (position[1] - match_keyword[1]) ** 2
                            matched_element = center(relative_elements[self.direction]["area"][inx])
                            border = relative_elements[self.direction]["area"][inx]
                            matched_elements.append(VisualElement(matched_element, self.element, match_text["text"], border))
                        else:
                            temp = (position[0] - match_keyword[0]) ** 2 + (position[1] - match_keyword[1]) ** 2
                            if temp < distance:
                                matched_element = center(relative_elements[self.direction]["area"][inx])
                                border = relative_elements[self.direction]["area"][inx]
                                matched_elements.insert(0, VisualElement(matched_element, self.element, match_text["text"], border))
                                distance = temp
                            else:
                                matched_elements.append(VisualElement(center(relative_elements[self.direction]["area"][inx]), self.element, match_text["text"], relative_elements[self.direction]["area"][inx]))
                if not matched_element:
                    for inx, e in enumerate(relative_elements[self.direction]["edge"]):
                        position = center(e)
                        if not matched_element:
                            distance = (position[0] - match_keyword[0]) ** 2 + (position[1] - match_keyword[1]) ** 2
                            matched_element = center(relative_elements[self.direction]["area"][inx])
                            border = relative_elements[self.direction]["area"][inx]
                            matched_elements.append(VisualElement(matched_element, self.element, match_text["text"], border))
                        else:
                            temp = (position[0] - match_keyword[0]) ** 2 + (position[1] - match_keyword[1]) ** 2
                            if temp < distance:
                                matched_element = center(relative_elements[self.direction]["area"][inx])
                                border = relative_elements[self.direction]["area"][inx]
                                matched_elements.insert(0, VisualElement(matched_element, self.element, match_text["text"], border))
                                distance = temp
                            else:
                                matched_elements.append(VisualElement(center(relative_elements[self.direction]["area"][inx]), self.element, match_text["text"], relative_elements[self.direction]["area"][inx]))
        self._img_shape = shape
        if self.direction in ["left", "right"]:
            matched_elements = sorted(matched_elements, key=lambda e: (e.location.x, e.location.y))
        if is_covert:
            return self.convert_location_and_sort_elements(matched_elements, shape, viewport_size, sort=False)
        else:
            return matched_elements

    def __call__(self, driver):
        return self.elements_on_browser(driver) if self.is_detect_all else self.element_on_browser(driver)


class RegionElementOrTextDisplayOnPage(BaseExpectation):

    def __init__(self, model, element, keyword=None, ref_name=None, beyond=None, direction=None, location_only=False, is_detect_all=False):
        super().__init__()
        self.model = model
        self.element = element.lower()
        self.keyword = str(keyword)
        self.ref_name = str(ref_name)
        self.is_detect_all = is_detect_all
        self.beyond = beyond
        self.direction = direction
        self.location_only = location_only
        self.ref_element = None

    def elements_on_image(self, image, viewport_size):
        is_text_element = self.element in ['static']
        matched_elements = []
        region, shape = self.region_on_image(image, viewport_size)
        if region is None:
            return []
        # return region only if there is no child element inner region element
        if self.keyword is None:
            return self.convert_location_and_sort_elements([VisualElement(center(region), self.element, self.ref_name)], shape, viewport_size)
        elif is_text_element:
            texts = TextDisplayOnPage(self.keyword).elements_on_image(image,viewport_size, False)
            matched_elements.extend(texts)
        else:
            if self.beyond:
                elements = ElementMatchOnPage(self.model, self.element, self.keyword, self.direction).elements_on_image(image, viewport_size, False)
            else:
                elements = ElementDisplayOnPage(self.model, self.element,self.keyword).elements_on_image(image,viewport_size, False)
            matched_elements.extend(elements)
        if len(matched_elements) == 0:
            return []
        return self.filter_elements_in_region(matched_elements, region, shape, viewport_size)

    def region_on_image(self, image, viewport_size):
        ref_element = None
        region_contours = []
        region = None
        contours, shape = Imager.recognize_contours(image)
        for c in contours:
            if c[1].find(self.ref_name.strip()) >= 0 or qualified(c[1], self.ref_name):
                ref_element = VisualElement(center(c[0]), 'static', c[1])
        if ref_element is None:
            return None, None
        region_contours = Imager.region_contours(image)
        for rc in region_contours:
            if ref_element.location.x >= rc[0] and \
                ref_element.location.x <= rc[2] and \
                ref_element.location.y >=rc[1] and \
                ref_element.location.y <= rc[3]:
                region = rc
                break
        self.ref_element = self.convert_location_and_sort_elements([ref_element], shape, viewport_size)[0]
        return region, shape

    #return ((x1,y1),(x2,y2))
    def region_location(self, driver):
        view_size = None
        if self.NEED_FULL_PAGE_SCAN:
            self.capture_full_screen(driver)
            view_size = self.get_body_size(driver)
        else:
            driver.save_screenshot(self._img)
            view_size = self.get_viewport_size(driver)
        region, shape = self.region_on_image(self._img)
        if region is None:
            return ()
        point_start = proportion([region[0], region[1]], view_size, shape)
        point_end = proportion([region[2], region[3]], view_size, shape)
        return (point_start, point_end)

    def filter_elements_in_region(self, elements, region, shape, viewport_size):
        region_elements = []
        for e in elements:
            if e.location.x >= region[0] and \
               e.location.x <= region[2] and \
               e.location.y >= region[1] and \
               e.location.y <= region[3]:
                region_elements.append(e)
        return self.convert_location_and_sort_elements(region_elements, shape, viewport_size)

    def elements_on_browser(self, driver):
        if self.NEED_FULL_PAGE_SCAN:
            self.capture_full_screen(driver)
            elements = self.elements_on_image(self._img, self.get_body_size(driver))
        else:
            driver.save_screenshot(self._img)
            elements = self.elements_on_image(self._img, self.get_viewport_size(driver))
        if self.ref_element is None:
            self.NEED_FULL_PAGE_SCAN = True
            return []
        elif self.NEED_FULL_PAGE_SCAN:
            # Not supported find_elements currently
            view_size = self.get_viewport_size(driver)
            x, y = self.ref_element.location.x, self.ref_element.location.y
            if y < view_size[1]:
                driver.execute_script(f"window.scrollTo({x}, 0);")
            elif y + view_size[1] > self.get_body_size(driver)[1]:
                driver.execute_script(f"window.scrollTo({x}, {self.get_body_size(driver)[1] - view_size[1]});")
            else:
                driver.execute_script(f"window.scrollTo({x}, {y - (view_size[1] / 2)});")
            self.NEED_FULL_PAGE_SCAN = False
            return []
        else:
            return elements

    def __call__(self, driver):
        if self.location_only:
            return self.region_location(driver)
        else:
            return self.elements_on_browser(driver) if self.is_detect_all else self.element_on_browser(driver)
