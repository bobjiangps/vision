# sights

test framework based on AI deep learning for web / app / desktop, with the purpose of cross project and cross platform and few code and low maintenance, test as human did

#### Install

run command:
> * pip install sights -i https://artifacts.dev.activenetwork.com/artifactory/api/pypi/pypi_vitual/simple

or define in requirement:
> --index-url https://artifacts.dev.activenetwork.com/artifactory/api/pypi/pypi_vitual/simple
> sights

suggest to use python>=3.8 (the final version of 3.8 is recommended)

for m1 mac, please install this package >= 1.3.6

please refer to [wiki](https://gitlab.dev.activenetwork.com/GlobalAutomation/framework3_dl/sights/-/wikis/How-to-train-images-and-evaluate-data) for some docs.

please refer to [sample project](https://gitlab.dev.activenetwork.com/GlobalAutomation/framework3_dl/framework3-demo) for how to design scripts and run tests. 
<hr>

#### Manual document
please refer to [framework3-manual](https://gitlab.dev.activenetwork.com/GlobalAutomation/framework3_dl/sights/-/wikis/Framework-3-Manual) for the details about how to develop scripts.
<hr>


#### Additional resource
>* the pre-trained AI model will be downloaded automatically.

if some elements cannot be recognized or not matched well, please contact bo.jiang@activenetwork.com
<hr>

#### IDE
suggest to use pycharm, suggest to use PEP 8 as code standard.
 
If you are using pycharm, go to preference - editor - inspector, check the following:
>* PEP 8 coding style violation
>* PEP 8 naming convention violation

for other IDE, we can install plugin which support PEP 8;
