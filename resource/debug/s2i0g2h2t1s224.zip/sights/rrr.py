# # def rising(prices):
# #     overall = 0  #
# #     rises = 0
# #     steadies = 0
# #     for p in prices:  #
# #         if p == "r":
# #             overall += 1  #
# #             rises += 1
# #         elif p == "f":  #
# #             overall -= 1
# #         else:
# #             steadies += 1
# #     return overall > 0 and rises > steadies  #
# #
# #
# # print(rising(["r", "s", "r", "f"]))
# # print(rising(["r", "s", "s"]))
# # print(rising(["f", "s", "r"]))
#
#
#
# # def same_letter_words(word, word_list):
# #     #
# #     for char in word:
# #         #
# #         letters.append(char)
# #     match_words = []
# #     #
# #         all_match = True
# #         for char in cand_word:
# #             if char not in letters:
# #                 #
# #         if all_match:
# #             match_words.append(cand_word)
# #     #
#
#
#
# #
# # HEL LOWORD
# # helloword
# #    lo
#
#
#
#
# def restore_sequence(msg1, msg2): # 12
#     idxs = [] # 11
#     for i in range(1, len(msg1)): # 4
#         idxs.append(i) #5
#     out = '' # 14
#     for j in idxs: # 1
#         if j >=len(msg2): #6
#             break #8
#         if msg1[i]
#             out += msg2[j] #7
#
#
